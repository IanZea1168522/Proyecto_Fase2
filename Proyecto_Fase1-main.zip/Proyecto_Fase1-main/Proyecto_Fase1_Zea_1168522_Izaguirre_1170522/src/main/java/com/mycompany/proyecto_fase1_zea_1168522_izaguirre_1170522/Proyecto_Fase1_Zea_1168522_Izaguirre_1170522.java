/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.proyecto_fase1_zea_1168522_izaguirre_1170522;

/**
 *
 * @author izeac
 */
public class Proyecto_Fase1_Zea_1168522_Izaguirre_1170522 {

    public static void main(String[] args) {
        new Inicio().setVisible(true);
    }
}
